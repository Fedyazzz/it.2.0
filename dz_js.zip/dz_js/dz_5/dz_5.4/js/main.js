function up_first(str) {
    if (typeof str !== "string") {
        return null;
    }

    let result = str.slice(0, 1).toUpperCase() + str.slice(1).toLowerCase();

    return result;
}

let str_result = up_first( "Иванов");
console.log(str_result);