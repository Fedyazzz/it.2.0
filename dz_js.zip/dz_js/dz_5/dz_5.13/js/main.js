let user = {};
user.name = "Вася";
user.surname = "Петров";
Object.defineProperty(user, "name", {value : "Сергей"});
delete user.name;