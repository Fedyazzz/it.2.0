function is_empty(obj) {
    console.log(typeof obj)
    console.log(obj.length)
    if (typeof obj !== "object") {
        return null;
    }

    return Object.keys(obj).length > 0 ? true : false;

}

let my_obj = {};

let result_obj = is_empty(my_obj);
console.log(result_obj);