function randomise(min, max, include = 0) {
    if (
      typeof min !== "number" ||
      typeof max !== "number" ||
      typeof include !== "number"
    ) {
      return null;
    }
  
    let result = Math.floor(Math.random() * (max - min + include)) + min;
    return result;
  }
  
  let random_result = randomise(25, 105);
  console.log(random_result);