function Create_calculator(name) {
    this.name = name;
}
let calc = new Create_calculator('Калькулятор');
console.log(calc);