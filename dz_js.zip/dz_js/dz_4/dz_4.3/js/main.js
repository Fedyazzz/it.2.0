function reverse_word (word) {
    return word.split("").reverse().join("")
}
let a = prompt("Введите слово", "");
console.log(reverse_word(a))