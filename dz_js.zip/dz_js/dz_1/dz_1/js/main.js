let N = prompt(`Введите количество километров`,`0`);
let D = prompt(`Введите диаметр колеса в дюймах`,`0`);

N=Number(N);
D=Number(D);

if(isNaN(N) || isNaN(D)) {
    console.error(`Даные введени неверно`);
}else{
    const METERS_IN_KILOMETR = 1000;
    const METERS_IN_INCH  = 0.0254;
    const PI =3.14;

    N = N * METERS_IN_KILOMETR
    D = D * METERS_IN_INCH
    let  result = N / (D * PI);
    let result2 = 4 * result;

    alert(`Ответ: ${result},${result2}`);
}