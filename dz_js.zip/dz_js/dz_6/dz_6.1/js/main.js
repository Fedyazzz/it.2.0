const SECOND = 1000;
const MINUTE = 60 * SECOND;
const HOUR = 60 * MINUTE;
const DAY = 24 * HOUR;


function get_tomorrow() {
    let arr = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря']
    let tomorrow  = new Date(Math.trunc(new Date().getTime() + DAY));
    tomorrow = tomorrow.getDate() + ' ' + arr[tomorrow.getMonth()]  + ' ' + tomorrow.getFullYear();
    return tomorrow;


}
console.log(get_tomorrow());