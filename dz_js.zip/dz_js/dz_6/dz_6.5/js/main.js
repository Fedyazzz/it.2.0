function get_day(date) {

    if (date instanceof Date) {
        let days_arr = ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'];
        return days_arr[date.getDay()];
        }

}

let star_date = '10/11/2021';

let date1 = star_date.split("/").reverse().join('-');


console.log(get_day(new Date(date1)));